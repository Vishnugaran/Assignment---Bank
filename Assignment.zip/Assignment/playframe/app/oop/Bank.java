package oop;

public class Bank {
    private String BankName;
    private String FirstName;
    private String LastName;
    private String Nic;
    private String Gender;
    private String address;
    private String BankID;
    private String PhoneNum;
    private Date DateOfBirth;

    public Bank(String bankName, String firstName, String lastName, String nic, String gender, String address, String bankID, String phoneNum, Date dateOfBirth) {
        BankName = bankName;
        FirstName = firstName;
        LastName = lastName;
        Nic = nic;
        Gender = gender;
        this.address = address;
        BankID = bankID;
        PhoneNum = phoneNum;
        DateOfBirth = dateOfBirth;
    }

    public String getBankName() {
        return BankName;
    }

    public void setBankName(String bankName) {
        BankName = bankName;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String firstName) {
        FirstName = firstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String lastName) {
        LastName = lastName;
    }

    public String getNic() {
        return Nic;
    }

    public void setNic(String nic) {
        Nic = nic;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBankID() {
        return BankID;
    }

    public void setBankID(String bankID) {
        BankID = bankID;
    }

    public String getPhoneNum() {
        return PhoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        PhoneNum = phoneNum;
    }

    public Date getDateOfBirth() {
        return DateOfBirth;
    }

    public void setDateOfBirth(Date dateOfBirth) {
        DateOfBirth = dateOfBirth;
    }
}
