package com.company;

import java.io.EOFException;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    static BankSystem BMS = new BankSystem();
    public static void main(String[] args) throws IOException {
//        try {
//            BMS.retrieve("playframe\\Club.txt");
//        } catch (EOFException | ClassNotFoundException e) {
//            System.out.println("Files is Empty");
//        }
        int option;
        do {
            Scanner input = new Scanner(System.in);

            System.out.println("\t" + "\t" + "\t" + "\t" + "-----------------------------------------------");
            System.out.println("\t" + "\t" + "\t" + "\t" + "************ Bank Establis in srilanka **********");
            System.out.println("\t" + "\t" + "\t" + "\t" + "-----------------------------------------------");
            System.out.println("1 - Create Bank Account");
            System.out.println("2 - Display Details ");
            System.out.println("--------------------------------------------");
            System.out.print("Enter The Number : ");
            while (!input.hasNextInt()) {       //Check Number Input
                System.out.println("Invalid input");
                System.out.print("Please re Enter The Number : ");
                input.next();
            }
            option = input.nextInt();

            switch (option) {       //Switch Cases For Options
                case 1:
                    BMS.CreateAccount();
                    break;
                case 2:
                    BMS.displayAccounts();
                    break;
                default:
                    System.out.println("---Invalid Input Try Again---");
                    main(args);
            }
        } while (option >= 1 && option <=2);

    }
}



