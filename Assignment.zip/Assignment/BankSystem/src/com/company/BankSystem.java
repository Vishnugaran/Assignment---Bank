package com.company;

import com.sun.xml.internal.ws.wsdl.writer.document.http.Address;
import jdk.nashorn.internal.ir.LexicalContext;
import jdk.nashorn.internal.ir.LexicalContextNode;

import javax.naming.Name;
import javax.swing.*;
import java.io.*;
import java.nio.file.FileStore;
import java.util.ArrayList;
import java.util.Scanner;

public class BankSystem<option> implements BankManagement {
    Scanner input = new Scanner(System.in);
    private ArrayList<Bank> AccoutDetails = new ArrayList<>();
    String BankName;
    String FirstName;
    String LastName;
    String Nic;
    String Gender;
    String address;
    String BankID;
    String PhoneNum;
    int day;
    int month;
    int year;


    @Override
    public void CreateAccount() throws IOException {
        Scanner input = new Scanner(System.in);
            System.out.println("");
            System.out.print("Enter The First Name : ");
            FirstName = input.next();
            if (!FirstName.matches("[a-zA-Z_]+")) {      //Check Input is Alphabet Letters
                System.out.println("You Can Input Letters only!");
                System.out.println();
                CreateAccount();
            } else {
                for (int i = 0; i < AccoutDetails.size(); i++) {
                    if (AccoutDetails.equals(FirstName)) {    //Check Name is in Arraylist
                        System.out.println("Already the Name is Available! ");
                        System.out.println();
                        CreateAccount();
                    }
                }
                System.out.print("Enter The Last Name : ");
                LastName = input.next();
                if (!LastName.matches("[a-zA-Z_]+")) {      //Check Input is Alphabet Letters
                    System.out.println("You Can Input Letters only!");
                    System.out.println();
                    CreateAccount();
                    } else {
                        for (int i = 0; i < AccoutDetails.size(); i++) {
                            if (AccoutDetails.equals(LastName)) {    //Check Name is in Arraylist
                                System.out.println("Already the Name is Available! ");
                                System.out.println();
                                CreateAccount();
                            }
                        }
                    System.out.print("Enter the Bank Name : ");
                        BankName = input.next();
                        if (!BankName.matches("[a-zA-Z_]+")) {      //Check Input is Alphabet Letters
                            System.out.println("You Can Input Letters only!");
                            System.out.println();
                            CreateAccount();
                        }

                            System.out.print("Enter the Bank ID (Numbers only) : ");
                            BankID = input.next();
                            if (!BankID.matches("[0-9]+")) { //Check Input is Number         /
                                System.out.println("You can input only Numbers!");
                                System.out.println();
                                CreateAccount();
                            }

                            System.out.print("Enter the Nic : ");
                            Nic = input.next();
                            if (Nic.matches("/^[0-9]{9}[vVxX]$/")) {
                                System.out.println("Invalid Nic!");
                                System.out.println();
                                CreateAccount();
                                //JOptionPane.showMessageDialog(null, "Invalid NIC ");
                            }
                            System.out.print("Enter the Phone Number : ");
                            PhoneNum = input.next();
                            if (!BankID.matches("[0-9]+")) { //Check Input is Number
                                System.out.println("You can input only Numbers!");
                                System.out.println();
                                CreateAccount();
                            }
                            System.out.print("Enter the Gender (MALE/FEMALE) : ");
                            Gender = input.next();
                            if (!Gender.matches("[a-zA-Z_]+")) {   //Check Input is Alphabet Letters
                                System.out.println("Address Must be in Letters");
                                System.out.println();
                                CreateAccount();
                            }
                            System.out.print("Enter the Address : ");{
                            address = input.next();
                            CreateAccount();
                        }
                        writeAndSave("playframe\\Club.txt");       //Call WriteAndSave Method for Save the Details
                    }
                }
        }




    @Override
    public void displayAccounts() {
        System.out.print("Insert First Name: ");
        FirstName = input.next();
        if (!FirstName.matches("[a-zA-Z_]+")) {      //Check ClubName is alphabet
            System.out.println("{Please re Enter the Name Must be in Letters!}");
        } else {
            int count = 0;
            for (int i = 0; i < AccoutDetails.size(); i++) {      //Check ClubName is in Arraylist
                if (AccoutDetails.get(i).getFirstName().equals(FirstName)) {
                    System.out.println();
                    System.out.println("FirstName " + AccoutDetails.get(i).getFirstName());
                    System.out.println();
                    System.out.println(" -LastName     : " + AccoutDetails.get(i).getLastName());
                    System.out.println(" -BankName     : " + AccoutDetails.get(i).getBankName());
                    System.out.println(" -BankID       : " + AccoutDetails.get(i).getBankID());
                    System.out.println(" -Nic Number   : " + AccoutDetails.get(i).getNic());
                    System.out.println(" -Gender       : " + AccoutDetails.get(i).getGender());
                    System.out.println(" -Phone Num    : " + AccoutDetails.get(i).getPhoneNum());
                    System.out.println(" -Address      : " + AccoutDetails.get(i).getAddress());
                    i = AccoutDetails.size();
                    count = 1;
                }
            }
            if (count == 0) {
                System.out.println("* " + FirstName + " is not there *");
            }
        }
    }


    @Override
    public void writeAndSave(String fileName) throws IOException {
        FileOutputStream foStream = new FileOutputStream(fileName);
        ObjectOutputStream objOutStream = new ObjectOutputStream(foStream);

        for (Bank bankSystem : AccoutDetails) {
            objOutStream.writeObject(AccoutDetails);
        }

        objOutStream.flush();
        foStream.close();
        objOutStream.close();
    }



    @Override
    public void retrieve(String fileName) throws IOException, ClassNotFoundException {
        FileInputStream fIStream = new FileInputStream(fileName);
        ObjectInputStream objInStream = new ObjectInputStream(fIStream);

        for(;;) {
            try {
                Bank Banksystem = (Bank) objInStream.readObject();
                AccoutDetails.add(Banksystem);
            }
            catch (EOFException e) {
                break;
            }
        }
        fIStream.close();
        objInStream.close();
    }
    }

