package com.company;
import java.io.IOException;

public interface BankManagement {
    void CreateAccount() throws IOException;
    void displayAccounts();
    void writeAndSave(String fileName) throws IOException;
    void retrieve(String fileName) throws IOException, ClassNotFoundException;

}
